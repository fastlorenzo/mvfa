ActionBarSherlock Plugins
=========================

Modules provided in this folder are plugins which add functionality to the
ActionBarSherlock library.

The requirements for implementing each pluging are detailed in the `README.md`
file in each plugin folder.
